from django.db import models

from usermanagement_api.models import Candidate ,Account,Contact,Notification


