import React from "react";

const NotFound404 = () => {
  return <div>NotFound404</div>;
};

export default NotFound404;
